package PRIMIERO_BIMESTRE.aula8.trabalho_facade;

public class Notificacao {

	public void enviarNotificacao(String mensagem) {
		System.out.println("Enviando Notificação: " + mensagem);
		
	}

}
