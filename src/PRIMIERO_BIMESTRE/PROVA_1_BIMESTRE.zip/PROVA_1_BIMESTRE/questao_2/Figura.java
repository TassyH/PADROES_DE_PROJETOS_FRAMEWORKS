package PRIMIERO_BIMESTRE.PROVA_1_BIMESTRE.questao_2;

public interface Figura {

    public double quadrado(double lado);
    public double retangulo(double base, double altura);
    public double circulo(double raio);

}
